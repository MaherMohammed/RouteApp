import React, { useState, useRef } from 'react';
import { View, StyleSheet } from 'react-native';
import MapView from 'react-native-maps';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import MapViewDirections from 'react-native-maps-directions';


const GOOGLE_MAPS_APIKEY = 'AIzaSyC3_KiTUVzcB79V7DilJBz9RtXCABWAi8U';
const origin = { latitude: 23.053150, longitude: 72.517100 };
const destination = { latitude: 23.053177, longitude: 72.517365 };

const App = () => {
  const [origin, setOrigin] = useState(null);
  const [destination, setDestination] = useState(null);
  const mapRef = useRef(null);

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <GooglePlacesAutocomplete
          placeholder='From'
          onPress={(data, details = null) => {
            setOrigin({
              description: data.description,
              location: details.geometry.location,
            });
          }}
          query={{
            key: GOOGLE_MAPS_APIKEY,
            language: 'en',
          }}
          fetchDetails
          styles={autocompleteStyles}
        />
        <GooglePlacesAutocomplete
          placeholder='To'
          onPress={(data, details = null) => {
            setDestination({
              description: data.description,
              location: details.geometry.location,
            });
          }}
          query={{
            key: GOOGLE_MAPS_APIKEY,
            language: 'en',
          }}
          fetchDetails
          styles={autocompleteStyles}
        />
      </View>
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={{
          latitude: 37.78825,
          longitude: -122.4324,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}
      >
        {origin && destination && (
          <MapViewDirections
            origin={{ latitude: origin.location.lat, longitude: origin.location.lng }}
            destination={{ latitude: destination.location.lat, longitude: destination.location.lng }}
            apikey={GOOGLE_MAPS_APIKEY}
            strokeWidth={4}
            strokeColor="red"
            onReady={result => {
              mapRef.current.fitToCoordinates(result.coordinates, {
                edgePadding: {
                  right: 20,
                  bottom: 20,
                  left: 20,
                  top: 20,
                },
              });
            }}
          />
        )}
      </MapView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
  },
  searchContainer: {
    position: 'absolute',
    width: '90%',
    top: 10,
    zIndex: 1,
    alignSelf: 'center',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
});

const autocompleteStyles = {
  textInputContainer: {
    backgroundColor: 'rgba(0,0,0,0)',
    borderTopWidth: 0,
    borderBottomWidth: 0,
  },
  textInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 5,
    paddingVertical: 5,
    paddingHorizontal: 10,
    fontSize: 16,
    marginTop: 5,
  },
  listView: {
    backgroundColor: '#FFFFFF',
  },
};

export default App;